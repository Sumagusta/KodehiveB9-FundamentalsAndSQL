package com.project.day9.consoledb;

public class ConnectionDB {
	
	public String jdbc = "com.mysql.cj.jdbc.Driver";
	public String url = "jdbc:mysql://localhost:3306/kampusb9";
	public String user = "root";
	public String password = "kodehive2020";
	
}
