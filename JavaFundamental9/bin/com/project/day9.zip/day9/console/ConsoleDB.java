package com.project.day8.console;

public class ConsoleDB {

		public String jdbc = "java.sql.Driver";
		public String url = "jdbc:mysql://localhost:3306/kampus9";
		public String user = "root";
		public String password = "kodehive2020";
		
}
