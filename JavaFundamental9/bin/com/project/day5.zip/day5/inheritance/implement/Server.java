package com.project.day5.inheritance.implement;

public interface Server {

	public void ipAddress();
	public void gateway();
	public void dns();
	public void nama();
	
}
