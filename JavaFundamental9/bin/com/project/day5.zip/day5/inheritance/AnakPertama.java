package com.project.day5.inheritance;

public class AnakPertama extends OrangTua {	
	
	public static void main(String[] args) {

		//instance
		AnakPertama ap = new AnakPertama();
		ap.aset1();
		ap.aset2();
	}

}
