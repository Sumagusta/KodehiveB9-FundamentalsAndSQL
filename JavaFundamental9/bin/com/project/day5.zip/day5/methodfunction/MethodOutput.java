package com.project.day5.methodfunction;

public class MethodOutput {

	public static int penjumlahan(int a, int b) {
		
		if (a > 5) {
			return a;
		} else {
			return b;
		}
	}

	public static void main(String[] args) {
		System.out.println(penjumlahan(40, 2));

	}

}
