package com.project.day5.orangtuaangkat;

import com.project.day5.inheritance.OrangTua;

public class AnakKedua extends OrangTua{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnakKedua ak = new AnakKedua();
		ak.aset2();
		
	}

}
