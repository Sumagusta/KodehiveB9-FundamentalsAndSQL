package com.project.day2;

public class SubstringPraktik {

	public static void main(String[] args) {

		String k = "Kodehive Academy";
									// hapus index
								// substring method 1
		System.out.println(k.substring(3));
		
		System.out.println(k.substring(0, 1));
		
	}

}
