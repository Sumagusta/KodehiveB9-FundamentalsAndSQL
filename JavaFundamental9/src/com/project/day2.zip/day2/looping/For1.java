package com.project.day2.looping;

public class For1 {

	public static void main(String[] args) {

		int num = 1;
		for (int i = 0; i < 5; i++) { // digunakan utk perulangan yang pasti
			System.out.println("index "+num);
			num++;			
		}
	}
}
