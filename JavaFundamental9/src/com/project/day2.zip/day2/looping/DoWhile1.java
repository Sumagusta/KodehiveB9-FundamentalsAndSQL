package com.project.day2.looping;

public class DoWhile1 {

	public static void main(String[] args) {

		int i = 6000;
		int numb = 1;
		do {
			System.out.println("index "+numb);
			numb++;
			i++;
		} while (i < 5);

	}

}
