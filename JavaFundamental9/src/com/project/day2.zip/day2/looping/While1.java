package com.project.day2.looping;

public class While1 {

	public static void main(String[] args) {
		
		// untuk perulangan tidak pasti
		int i =6;
		int numb = 10;
		while (i < 5) {
			System.out.println("index - "+numb);
			numb++;
			i++;
		}
	}
}
