package com.project.day2;

public class Konversi {

	public static void main(String[] args) {
		
		int numb1 = 700;
		String numb2 = "200";
		
		double result = numb1 * Double.valueOf(numb2);
		System.out.println(result);
	}

}
