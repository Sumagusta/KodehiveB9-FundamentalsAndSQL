package com.project.day7.bahas.exception;

import java.io.IOException;

public class CallThrows {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		ThrowsExceptionHandling a = new ThrowsExceptionHandling();
		
		a.divideNum(4, 0);
		

	}

}
