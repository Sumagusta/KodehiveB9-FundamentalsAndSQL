package com.project.day4.oop.modifier2;

public class DataProtected {
	
	protected void minuman() {
		System.out.println("AQui");
		System.out.println("Teh Pocong");
	}
	
}
