package com.project.day4.oop.modifier2;

public class AmbilIsiStorage {

	public static void main(String[] args) {

		
		
	}

}
