package com.project.day4.oop.constructor;

public class Toko {
	
	public Toko() {
		System.out.println("SELAMAT DATANG DI TOKO KAMI");
	}
	public void Gula() {
		System.out.println("gula pasir");
		System.out.println("gula aren");
	}

	public static void main(String[] args) {

		
	}

}
