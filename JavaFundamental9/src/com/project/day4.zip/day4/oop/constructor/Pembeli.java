package com.project.day4.oop.constructor;

public class Pembeli {

	public static void main(String[] args) {
		
		new Toko().Gula();
		
	}

}
