package com.project.day4.oop;

public class Oop1 {
	public static void main(String[] args) {
		

	}

}
