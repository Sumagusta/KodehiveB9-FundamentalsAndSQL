package com.project.day6.generic;

public class CallGenericInterface implements GenericInterface<Double> {

	
	public void setType1(Integer value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType2(Integer value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType3(Integer value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType1(String value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType2(String value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType3(String value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType1(Double value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType2(Double value) {
		// TODO Auto-generated method stub
		
	}

	
	public void setType3(Double value) {
		// TODO Auto-generated method stub
		
	}

}
