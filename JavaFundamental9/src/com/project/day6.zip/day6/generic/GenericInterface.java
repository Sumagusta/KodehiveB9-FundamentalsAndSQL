package com.project.day6.generic;

public interface GenericInterface<T> {

	public void setType1(T value);
	public void setType2(T value);
	public void setType3(T value);
}
