package com.project.day6.polymorphism.overriding;

public class HalamanA {
	
	public void download() {
		System.out.println(".pdf");
	}
	
	public void upload() {
		System.out.println("Upload");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
