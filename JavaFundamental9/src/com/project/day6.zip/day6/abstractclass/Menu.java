package com.project.day6.abstractclass;

public abstract class Menu {
	
	public Menu() {
		System.out.println("WELCOME TO MY CAFFE");
	}
	
	public abstract void makanan();
	public abstract void minuman();
}
